<?php
$dbcnx=mysqli_connect("localhost","dbadm","SecurePassword2021@th3x0ne","db_mini");
if(!$dbcnx)
{
    die("undefined data base");
}

?>
